var saveSearch = [];
var counter = 0;
var currentSearch = new Object();
var defaultHeight = 100; 

$("#header").click(function() {
	if($("#credits").hasClass('visible'))
	{
		$("#credits").removeClass('visible');
		$("#credits").addClass('invisible');
		$("#arrow").removeClass('upArrow');
		$("#arrow").addClass('downArrow');
	}
	else
	{
		$("#credits").removeClass('invisible');
		$("#credits").addClass('visible');
		$("#arrow").removeClass('downArrow');
		$("#arrow").addClass('upArrow');

	}
});

//Send JSONP Request when submit is clicked
$("#artistForm").submit(function() {
    //reset fields                                 
    $("#error").html("");
    var searched = $('#artist').val(); 
    if (searched === ''){
    	// document.getElementById('artist').style.background-color='#EBC0C0';
    	$('#artist').css('background-color','#F5DADA');
    	return false;
    }
    $('#artist').css('background-color','white');

    currentSearch.searchString = searched;
    
    //ADDS RECENT SEARCH TO DOM
    $('#recentText').html($('#recentText').html()+'<p id=number' + counter + '><a href=#>' + searched + '</a></p>');
    console.log(counter);
    var elem = document.getElementById('number'+counter);
    console.log(elem);
    elem.addEventListener('click', recentSearch, false);

    // console.log(counter);
    // console.log('elem' + elem);
    $.ajax({
        url: 'http://ws.audioscrobbler.com/2.0',
        data: {
            method: 'artist.getInfo',
            autocorrect: '1', //Turns on autocorrecting
            artist: $("#artist").val(),
            format: 'json',
            api_key: '028a648a94b5ca3a256ed241d7952a20',
            callback: "getTag"
        },
        dataType: 'jsonp'
    }); 
    return false;
});

function getTag(result) {
    if(result.error != null) //if artist entered could not be found
    {
    	$('#dataCanvas').hide();
    	$('#topCharts').html('');
    	$('#topTracks').html(''); 
        $("#error").html("<p>The artist you requested could not be found. Please try again.</p>");
        resizeAll();
    }
    else
    {
    	// if (!tag) {	console.log('here!');resizeAll(); return false;}
    	var tag; 
    	console.log(result.artist.tags.tag);
    	if (!(result.artist.tags.tag)) {console.log('here!!!!');resizeAll(); return false;}
        var tag = result.artist.tags.tag[0].name;
        currentSearch.tag = tag; 
        $.ajax({
            url: 'http://ws.audioscrobbler.com/2.0',
            data: {
                method: 'tag.getTopTracks',
                limit: '5',
                tag: tag,
                format: 'json',
                api_key: '028a648a94b5ca3a256ed241d7952a20',
                callback: "getTracks"
            },
            dataType: 'jsonp'
        });
    }   
};

function getTracks(result) {
    var newHeight = 0;
    if(result.error != null) //if artist entered could not be found
    {
    	$('#dataCanvas').hide();
    	$('#topCharts').html('');
    	$('#topTracks').html(''); 
        $("#error").html("<p>The artist you requested could not be found. Please try again.</p>");
        resizeAll();
    }
    else
    {
        var tracks = result.toptracks.track;
        currentSearch.tracks = tracks; 

        saveSearch[counter] = currentSearch; 
		
		//ADD TOP TRACKS TO DOM
		// if ($('#topTracks').html() === ''){
		// 	newHeight = $('#appTitle').height() + $('#artistForm').height();
		// 	console.log("THIS!");
		// }

		$('#topTracks').html(''); 		
		$('#topCharts').html(''); 

		$('#topTracks').html('<h2>Top tracks for this genre:</h2>')
    	for (var i = 0; i < currentSearch['tracks'].length;i++){
    		$('#topTracks').html($('#topTracks').html() + '<p>' + currentSearch['tracks'][i]['artist']['name'] + ' : ' +
    		currentSearch['tracks'][i]['name'] + '</p>');
        }

  //       if (newHeight !== 0){
	 //        newHeight = $('#appBox').height();
	 //        $('#recent').css({ height:newHeight });
	 //        $('#divider').animate({ height:newHeight }, 2000);
		// }

		$.ajax({
            url: 'http://ws.audioscrobbler.com/2.0',
            data: {
                method: 'tag.getWeeklyArtistChart',
                limit: '6',
                tag: currentSearch.tag,
                format: 'json',
                api_key: '028a648a94b5ca3a256ed241d7952a20',
                callback: "getWeeklyChart"
            },
            dataType: 'jsonp'
        });

    }
};

function getWeeklyChart(result){

	currentSearch.weeklyChart = result['weeklyartistchart']['artist'];

	$('#dataCanvas').show();

	$('#dataCanvas').focus();
	//canvas shit currentSearch.weeklyChart[x].weight 

	$('#topCharts').html('<h2>Top artists this week:</h2>');
	for (var i = 0; i < currentSearch.weeklyChart.length;i++){
    	$('#topCharts').html($('#topCharts').html() + '<div class="artistPicDiv"><img src="' + currentSearch.weeklyChart[i]['image'][2]['#text'] + '"></img>' + '<p>' + currentSearch.weeklyChart[i]['name'] + '</p></div>');
    }

    $('#topCharts').html($('#topCharts').html() + '<h2>Artist plays this week:</h2>');
    resizeAll();
    counter++; 
    currentSearch = new Object(); 
}

function resizeAll(){
	console.log('RESIZING');
	var newHeight = 0;
	var recentHeight = $('#title').height() + $('#recentText').height();
	console.log(recentHeight);
	if (recentHeight < defaultHeight) recentHeight = defaultHeight;
	var appHeight = $('#content').height();
	if (appHeight < defaultHeight) appHeight = defaultHeight;
	if (appHeight > recentHeight){
		console.log('appHeight greater:');
		console.log(appHeight);
		newHeight = appHeight;
	}
	else{ 
		console.log('recentHeight greater:');
		console.log(recentHeight);
		newHeight = recentHeight + 20;
	}
	$('#appBox').css({ height:newHeight });
	$('#recent').css({ height:newHeight });
	$('#divider').animate({ height:newHeight+15 }, 500);
}

function recentSearch() {
	alert('aaaaa');
}