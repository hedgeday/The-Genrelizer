var saveSearch = [];
var counter = 0;
var currentSearch = new Object(); 

function toggleCredits(){
	var logo = document.getElementsByClassName('header')[0];
	logo.addEventListener('click', click, false);
	console.log('here!');
}

/*Toggle comment hidden/revealed state*/
click = function(e){ 
	var name = document.getElementById('invisibleCred');
	if (!name) name = document.getElementById('visibleCred');
	if (name.id === 'invisibleCred'){
		console.log('this!');
		name.id = 'visibleCred';
	}
	else{
		name.id = 'invisibleCred';	
	}
}

//Send JSONP Request when submit is clicked
$("#artistForm").submit(function() {
    //reset fields                                 
    $("#error").html("");
    $("#artistinfo").html("");    
    var searched = $('#artist').val(); 
    currentSearch.searchString = searched;
    
    //ADDS RECENT SEARCH TO DOM
    $('#recentText').html($('#recentText').html()+'<p>' + searched + '</p>');

    $.ajax({
        url: 'http://ws.audioscrobbler.com/2.0',
        data: {
            method: 'artist.getInfo',
            autocorrect: '1', //Turns on autocorrecting
            artist: $("#artist").val(),
            format: 'json',
            api_key: '028a648a94b5ca3a256ed241d7952a20',
            callback: "getTag"
        },
        dataType: 'jsonp'
    }); 
    return false;
});

function getTag(result) {
    if(result.error != null) //if artist entered could not be found
    {
        $("#error").html("The artist you requested could not be found. Please try again.");
    }
    else
    {
        var tag = result.artist.tags.tag[0].name;
        currentSearch.tag = tag; 

        $.ajax({
            url: 'http://ws.audioscrobbler.com/2.0',
            data: {
                method: 'tag.getTopTracks',
                limit: '5',
                tag: tag,
                format: 'json',
                api_key: '028a648a94b5ca3a256ed241d7952a20',
                callback: "getTracks"
            },
            dataType: 'jsonp'
        });
    }   
};

function getTracks(result) {
    var newHeight = 0;
    if(result.error != null) //if artist entered could not be found
    {
        $("#error").html("The artist you requested could not be found. Please try again.");
        newHeight = $('#content').height() + $('#error').height() + 10;
        console.log(newHeight);
        $('#appbox').css({ height:newHeight });
	    $('#recent').css({ height:newHeight });
	    $('#divider').animate({ height:newHeight }, 2000);
    }
    else
    {
        var tracks = result.toptracks.track;
        currentSearch.tracks = tracks; 

        saveSearch[counter] = currentSearch; 
        console.log(saveSearch[counter]);
		
		//ADD TOP TRACKS TO DOM
		if ($('#toptracks').html() === ''){
			newHeight = $('.box').height();
			console.log("THIS!");
		}
		console.log('box ht: ' + newHeight);
		$('#toptracks').html(''); 
		// $('#toptracks').visibility('hidden');
    	for (var i = 0; i < saveSearch[counter]['tracks'].length;i++){
    		$('#toptracks').html($('#toptracks').html() + '<p>' + saveSearch[counter]['tracks'][i]['artist']['name'] + ' : ' +
    		saveSearch[counter]['tracks'][i]['name'] + '</p>');
        }
        if (newHeight !== 0){
	        newHeight += $('#toptracks').height()+10;
	        // $('#appbox').css({ height:newHeight });
	        $('#recent').css({ height:newHeight });
	        $('#appbox').animate({ height:newHeight }, 2000);
	        		// $('#toptracks').visibility('visible');

	        $('#divider').animate({ height:newHeight }, 2000);
		}


        counter++; 
        currentSearch = new Object(); 
    }
};

