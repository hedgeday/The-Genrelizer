var saveSearch = [];
var counter = 0;
var currentSearch = new Object(); 

$("#header").click(function() {
	if($("#credits").hasClass('visible'))
	{
		$("#credits").removeClass('visible');
		$("#credits").addClass('invisible');
	}
	else
	{
		$("#credits").removeClass('invisible');
		$("#credits").addClass('visible');
	}
});

//Send JSONP Request when submit is clicked
$("#artistForm").submit(function() {
    //reset fields                                 
    $("#error").html("");
    var searched = $('#artist').val(); 
    if (searched === ''){
    	// document.getElementById('artist').style.background-color='#EBC0C0';
    	$('#artist').css('background-color','#EBC0C0');
    	return false;
    }
    currentSearch.searchString = searched;
    
 //    //ADDS RECENT SEARCH TO DOM
 //    $('#recentText').html($('#recentText').html()+'<p>' + searched + '</p>');
	// if ($('#recent').height() >  $('#appbox').height()){
	// 	if ($('#recentText').height() > $('#appbox').height()){
	//      		console.log('RESIZING RECENT');
	//      		newHeight = $('#recentText').height();
	//      		$('#recent').css({ height:newHeight }, 1000);
	//      		$('#divider').animate({ height:newHeight }, 1000);
	//      		$('#appBox').css({ height:newHeight }, 1000);
	//     }
	// }

    $.ajax({
        url: 'http://ws.audioscrobbler.com/2.0',
        data: {
            method: 'artist.getInfo',
            autocorrect: '1', //Turns on autocorrecting
            artist: $("#artist").val(),
            format: 'json',
            api_key: '028a648a94b5ca3a256ed241d7952a20',
            callback: "getTag"
        },
        dataType: 'jsonp'
    }); 
    return false;
});

function getTag(result) {
    if(result.error != null) //if artist entered could not be found
    {
        $("#error").html("<p>The artist you requested could not be found. Please try again.</p>");
        // newHeight = $('#content').height() + $('#error').height() + 10;
        // console.log(newHeight);
    }
    else
    {
        var tag = result.artist.tags.tag[0].name;
        currentSearch.tag = tag; 
        $.ajax({
            url: 'http://ws.audioscrobbler.com/2.0',
            data: {
                method: 'tag.getTopTracks',
                limit: '5',
                tag: tag,
                format: 'json',
                api_key: '028a648a94b5ca3a256ed241d7952a20',
                callback: "getTracks"
            },
            dataType: 'jsonp'
        });
    }   
};

function getTracks(result) {
    var newHeight = 0;
    if(result.error != null) //if artist entered could not be found
    {
    	$('#topTracks').html(''); 
        $("#error").html("<p>The artist you requested could not be found. Please try again.</p>");

    }
    else
    {
        var tracks = result.toptracks.track;
        currentSearch.tracks = tracks; 

        saveSearch[counter] = currentSearch; 
		
		//ADD TOP TRACKS TO DOM
		if ($('#topTracks').html() === ''){
			newHeight = $('#appTitle').height() + $('#artistForm').height();
			console.log("THIS!");
		}

		$('#topTracks').html(''); 		
		$('#topCharts').html(''); 

    	for (var i = 0; i < currentSearch['tracks'].length;i++){
    		$('#topTracks').html($('#topTracks').html() + '<p>' + currentSearch['tracks'][i]['artist']['name'] + ' : ' +
    		currentSearch['tracks'][i]['name'] + '</p>');
        }

        if (newHeight !== 0){
	        newHeight = $('#appBox').height();
	        $('#recent').css({ height:newHeight });
	        $('#divider').animate({ height:newHeight }, 2000);
		}

		$.ajax({
            url: 'http://ws.audioscrobbler.com/2.0',
            data: {
                method: 'tag.getWeeklyArtistChart',
                limit: '6',
                tag: currentSearch.tag,
                format: 'json',
                api_key: '028a648a94b5ca3a256ed241d7952a20',
                callback: "getWeeklyChart"
            },
            dataType: 'jsonp'
        });

    }
};

function getWeeklyChart(result){

	currentSearch.weeklyChart = result['weeklyartistchart']['artist'];

	$('#dataCanvas').show();

	$('#dataCanvas').focus();
	//canvas shit currentSearch.weeklyChart[x].weight 

	$('#topCharts').html('<p>Top Artists this week:</p>');
	for (var i = 0; i < currentSearch.weeklyChart.length;i++){
    	$('#topCharts').html($('#topCharts').html() + '<div class="artistPicDiv"><img src="' + currentSearch.weeklyChart[i]['image'][2]['#text'] + '"></img>' + '<p>' + currentSearch.weeklyChart[i]['name'] + '</p></div>');
    }

    counter++; 
    currentSearch = new Object(); 
}

function resize3Divs(newHeight){
	$('#appBox').css({ height:newHeight });
	$('#recent').css({ height:newHeight });
	$('#divider').animate({ height:newHeight }, 2000);
}